package com.iflytek.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.iflytek.bean.Menu;

/**
 * <p>
 *  Mapper 接口
 * </p>
 */
public interface MenuMapper extends BaseMapper<Menu> {

}
