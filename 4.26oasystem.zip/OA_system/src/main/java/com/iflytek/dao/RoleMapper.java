package com.iflytek.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.iflytek.bean.Role;

/**
 * <p>
 *  Mapper 接口
 * </p>
 */
public interface RoleMapper extends BaseMapper<Role> {

}
