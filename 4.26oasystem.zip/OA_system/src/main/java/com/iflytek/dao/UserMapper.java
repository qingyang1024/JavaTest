package com.iflytek.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.iflytek.bean.ShiroUser;

/**
 * <p>
 *  Mapper 接口
 * </p>
 */
public interface UserMapper extends BaseMapper<ShiroUser> {

}
