package com.iflytek.dao;


import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.iflytek.bean.OperationLeaveUser;

/**
 * <p>
 *  Mapper 接口
 * </p>
 */
public interface OperationLeaveUserMapper extends BaseMapper<OperationLeaveUser> {

}
