package com.iflytek.config.properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 系统的一些属性
 */
@Component
public class OaProperties {
	public static final String PREFIX = "OA";
	/**
	 * 验证码开关
	 */
	@Value("${OA.kaptchaswich}")
	private boolean kptchaswich = false;

	public boolean isKptchaswich() {
		return kptchaswich;
	}

	public void setKptchaswich(boolean kptchaswich) {
		this.kptchaswich = kptchaswich;
	}


	
	
	
}
