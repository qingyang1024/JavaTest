package com.iflytek.service;

import com.iflytek.bean.Memo;

import java.util.List;

public interface MemoService {
	String addMemo(String title, String text, String time);
	List<Memo> getUserMemoList();
	String deleteMemo(int id);
}
