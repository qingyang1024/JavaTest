package com.iflytek.service;

import com.iflytek.bean.LoginLog;
import com.iflytek.bean.ShowLog;

import java.util.List;


public interface LoginLogService {
	
	public List<LoginLog> getAllLoginLog();

	public List<ShowLog> getAllShowLoginLog();
	
	public String deleteALLLoginLog();
	
	public String getShowLogJson(int page, int count);
	
}
