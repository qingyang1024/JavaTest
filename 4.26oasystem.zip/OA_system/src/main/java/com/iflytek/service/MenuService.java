package com.iflytek.service;

import com.iflytek.bean.Menu;

import java.util.List;

public interface MenuService {
	List<Menu> getUserMenu();
	String menuTreeData();
}
