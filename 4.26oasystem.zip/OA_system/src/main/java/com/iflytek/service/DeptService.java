package com.iflytek.service;

import com.iflytek.bean.Dept;

import java.util.List;

public interface DeptService {
    public String getAllDeptJson(int page, int count);
    String deptListForUserAdd();
    String addDept(String deptName);
    String modifyDept(String id, String deptName);
    String deleteDept(String id);
    List<Dept> getAllDept();
}
