package com.iflytek.service.impl;

import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.iflytek.bean.Memo;
import com.iflytek.constant.Constant;
import com.iflytek.dao.MemoMapper;
import com.iflytek.service.MemoService;
import com.iflytek.utils.Userinfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MemoServiceImpl implements MemoService{
	@Autowired
	private MemoMapper mapper;
	
	@Override
	public String addMemo(String title, String text, String time) {
		Memo memo = new Memo();
		memo.setTitle(title);
		memo.setText(text);
		memo.setTime(time);
		memo.setUserid(Userinfo.getUserid());
		int result = mapper.insert(memo);
		if (result == 1) {
			return Constant.OPERATION_SUCCESS_CODE;
		}
		return Constant.ERROR_ADD_MEMO;
	}

	@Override
	public List<Memo> getUserMemoList() {
		return mapper.selectList(new EntityWrapper<Memo>().eq("userid", Userinfo.getUserid()));
	}

	@Override
	public String deleteMemo(int id) {
		int result = mapper.deleteById(id);
		if (result == 1) {
			return Constant.OPERATION_SUCCESS_CODE;
		}
		return Constant.ERROR_DELETE_MEMO;
	}

}
