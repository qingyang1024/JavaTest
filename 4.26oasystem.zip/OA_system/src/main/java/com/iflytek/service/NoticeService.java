package com.iflytek.service;

import com.iflytek.bean.Notice;
import com.iflytek.bean.ShowNotice;

import java.util.List;

public interface NoticeService {
	
	public List<Notice> getAllNotice();
	/**
	 * 主页显示的15个Notice
	 * @return
	 */
	public List<Notice> getIndexNotice();
	
	public List<ShowNotice> getAllShowNotice();
	
	public int sendSystemNotice(String body);
	
	public int sendConmonNotice(String body, String recive);
	
	
	
}
