package com.iflytek.service;

import com.iflytek.bean.User;

import java.util.List;

public interface UserService {
	public String getAllUserJson(int page, int count);

	public List<User> getAllUser();

	public String addUser(String username, String avator, String dept, String role);

	public String resetPassword(int id);

	public String deleteUser(int id);

	public String modifyInfo(String newId, String newDeptId, String newRoleId);

	public String changePassword(String oldPassword, String newPassword);
}
