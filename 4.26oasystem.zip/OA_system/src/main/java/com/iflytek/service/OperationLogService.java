package com.iflytek.service;

import com.iflytek.bean.OperationLog;
import com.iflytek.bean.ShowLog;

import java.util.List;


public interface OperationLogService {
	
	public List<OperationLog> getAllOperationLog();

	public List<ShowLog> getAllShowLog();
	
	public String deleteALLLog();
	
	public String getShowLogJson(int page, int count);
	
	
}
