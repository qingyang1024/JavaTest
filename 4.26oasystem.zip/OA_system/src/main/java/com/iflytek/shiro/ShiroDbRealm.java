package com.iflytek.shiro;


import com.iflytek.bean.ShiroUser;
import com.iflytek.bean.User;
import com.iflytek.dao.RoleMapper;
import com.iflytek.dao.UserMapper;
import com.iflytek.utils.BeanUtil;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.util.ByteSource;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;


public class ShiroDbRealm extends AuthorizingRealm{
	
	@Resource
	private UserMapper userMapper;
	@Resource
	private RoleMapper roleMapper;
	@Autowired
	private BeanUtil beanUtil;
	
	/**
	 * 授权
	 */
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
		User user = (User) principals.getPrimaryPrincipal();
		info.addRole(user.getRole());
		return info;
	}
	/**
	 * 登录认证
	 */
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationtoken) throws AuthenticationException {
		UsernamePasswordToken token = (UsernamePasswordToken) authenticationtoken;
		ShiroUser temp = new ShiroUser();
		temp.setUsername(token.getUsername());
		ShiroUser dbUser = userMapper.selectOne(temp);
		User user =beanUtil.toUser(dbUser);
		
		if (dbUser == null){
			throw new CredentialsException();
		}    
		SimpleAuthenticationInfo authinfo = new SimpleAuthenticationInfo(user, 
				dbUser.getPassword(), ByteSource.Util.bytes(dbUser.getSalt()), getName());
		return authinfo;
	}


	
}
