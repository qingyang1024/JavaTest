package net.sppan.base.service;

import net.sppan.base.service.support.IBaseService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import net.sppan.base.entity.User;


public interface IUserService extends IBaseService<User, Integer> {

	User findByUserName(String username);

	void saveOrUpdate(User user);

	void grant(Integer id, String[] roleIds);

	Page<User> findAllByLike(String searchText, PageRequest pageRequest);

	void updatePwd(User user, String oldPassword, String password1, String password2);

}
