package com.iflytek.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.iflytek.office.entity.Dept;



public interface DeptService extends IService<Dept> {

}
