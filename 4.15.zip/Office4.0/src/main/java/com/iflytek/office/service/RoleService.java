package com.iflytek.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.iflytek.office.entity.Role;
import java.util.List;


public interface RoleService extends IService<Role> {

	List<Integer> queryRolePermissionIdsByRid(Integer roleId);


	void saveRolePermission(Integer roleId, Integer[] ids);

}
