package com.iflytek.office.service.impl;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.iflytek.office.entity.Dept;
import com.iflytek.office.mapper.DeptMapper;
import com.iflytek.office.service.DeptService;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;


@Service
@Transactional
public class DeptServiceImpl extends ServiceImpl<DeptMapper, Dept> implements DeptService {
	
	@Override
	public Dept getOne(Wrapper<Dept> queryWrapper) {
		return super.getOne(queryWrapper);
	}
	
	@Override
	public boolean updateById(Dept entity) {
		return super.updateById(entity);
	}
	
	@Override
	public boolean removeById(Serializable id) {
		return super.removeById(id);
	}

}
