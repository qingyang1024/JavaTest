package com.iflytek.office.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.iflytek.office.entity.Dept;


public interface DeptMapper extends BaseMapper<Dept> {

}
