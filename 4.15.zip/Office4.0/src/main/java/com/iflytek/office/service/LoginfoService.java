package com.iflytek.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.iflytek.office.entity.Loginfo;


public interface LoginfoService extends IService<Loginfo> {

}
