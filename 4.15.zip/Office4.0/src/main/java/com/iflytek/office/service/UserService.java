package com.iflytek.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.iflytek.office.entity.User;


public interface UserService extends IService<User> {

}
