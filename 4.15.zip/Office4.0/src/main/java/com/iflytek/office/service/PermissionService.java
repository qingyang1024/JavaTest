package com.iflytek.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.iflytek.office.entity.Permission;

public interface PermissionService extends IService<Permission> {

}
