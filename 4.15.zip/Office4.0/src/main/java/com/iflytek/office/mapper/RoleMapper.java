package com.iflytek.office.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.iflytek.office.entity.Role;
import org.apache.ibatis.annotations.Param;

import java.io.Serializable;
import java.util.List;


public interface RoleMapper extends BaseMapper<Role> {


	void deleteRolePermissionByRid(Serializable id);

	void deleteRoleUserByRid(Serializable id);


	List<Integer> queryRolePermissionIdsByRid(Integer roleId);


	void saveRolePermission(@Param("rid") Integer rid, @Param("pid") Integer pid);

}
