package com.iflytek.office.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.iflytek.office.entity.Notice;



public interface NoticeService extends IService<Notice> {

}
