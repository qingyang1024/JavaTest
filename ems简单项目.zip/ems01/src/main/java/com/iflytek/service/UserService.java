package com.iflytek.service;

import com.iflytek.entity.User;
import org.apache.ibatis.annotations.Param;

public interface UserService {
    //保存用户
    void save(User user);
    //登录的方法
    User login(String username,String password);
}
