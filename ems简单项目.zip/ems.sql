/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50715
 Source Host           : localhost:3306
 Source Schema         : ems

 Target Server Type    : MySQL
 Target Server Version : 50715
 File Encoding         : 65001

 Date: 02/04/2020 21:08:16
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for t_emp
-- ----------------------------
DROP TABLE IF EXISTS `t_emp`;
CREATE TABLE `t_emp`  (
  `id` varchar(40) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `name` varchar(40) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `salary` double(7, 2) NULL DEFAULT NULL,
  `age` int(3) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_emp
-- ----------------------------
INSERT INTO `t_emp` VALUES ('1', '1', 1.00, 1);

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user`  (
  `id` varchar(40) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `username` varchar(40) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `realname` varchar(40) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `password` varchar(4) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  `sex` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('1', '123', '123', '123', '1');
INSERT INTO `t_user` VALUES ('39b92fce-a4c5-4ecb-8f34-f97e2da67d10', '1', '2', '123', '1');
INSERT INTO `t_user` VALUES ('52a39c19-4a7c-490f-8074-146eb14921fb', '1', '2', '123', '1');
INSERT INTO `t_user` VALUES ('71070eca-a083-4b69-bec6-c2bc252b8a58', '1', '2', '123', '1');
INSERT INTO `t_user` VALUES ('7480c4e5-62ce-4d21-8085-9c1ed0543a80', 'qingyang', '小杨庆', '1', '男');
INSERT INTO `t_user` VALUES ('a90c0154-530a-4ffa-a1b3-7a4e918f4f03', '1', '2', '123', '1');
INSERT INTO `t_user` VALUES ('aa687dc5-bd33-43e9-9c27-92e65000be83', 'qingyang', '小杨', '1234', '女');
INSERT INTO `t_user` VALUES ('dc0d6feb-d31f-4e25-b042-a1c8c4e9f8c6', 'yangqing', '杨庆', '123', '女');

SET FOREIGN_KEY_CHECKS = 1;
